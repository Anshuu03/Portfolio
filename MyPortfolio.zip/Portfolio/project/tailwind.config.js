/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        peach: {
          100: '#FFE5D9',
          200: '#FFD0BF',
          300: '#FFBBA4',
          400: '#FFA68A',
          500: '#FF916F',
          600: '#FF7C55',
          700: '#FF673A',
          800: '#FF5220',
          900: '#FF3D05',
        },
      },
    },
  },
  plugins: [],
};