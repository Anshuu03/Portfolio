import React, { useState, useEffect } from 'react';
import { 
  LinkedinIcon, 
  GithubIcon, 
  MailIcon, 
  PhoneIcon, 
  CodeIcon, 
  BookOpenIcon, 
  ServerIcon,
  ExternalLinkIcon,
  SunIcon,
  MoonIcon,
  FileTextIcon
} from 'lucide-react';

const Portfolio = () => {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDark);
  }, [isDark]);

  const projects = [
    {
      name: "Perplexity Game Play",
      description: "Interactive game development project showcasing problem-solving skills",
      technologies: ["React", "JavaScript", "C++"],
      githubLink: "https://github.com/Anshuu03/Perplexity-game-play"
    },
    {
      name: "User-Centric Signup",
      description: "User registration system with enhanced authentication mechanisms",
      technologies: ["Frontend", "Backend"],
      githubLink: "https://github.com/Anshuu03/User-Centric-Signup"
    },
    {
      name: "Online Restaurant Booking System",
      description: "E-commerce style table reservation platform for restaurants",
      technologies: ["MERN Stack", "Web Development"],
      githubLink: "https://github.com/Anshuu03/Online-Restaurant-Booking-System-"
    },
    {
      name: "Walmart Sales Prediction",
      description: "Data science project for sales forecasting (Sparkathon Converge Participant)",
      technologies: ["Python", "Data Science"],
      githubLink: "https://github.com/Anshuu03/Online-Restaurant-Booking-System-"
    }
  ];

  const skills = {
    programmingLanguages: ["C++", "Java", "Python", "Django"],
    frontend: ["HTML", "CSS", "JavaScript", "React.js", "Bootstrap"],
    backend: ["MongoDB", "Express.js", "Node.js", "SQL"],
    tools: ["VS Code", "Visual Studio 2022", "GitHub", "MySQL", "Jupyter Notebook"]
  };

  return (
    <div className={`min-h-screen ${isDark ? 'bg-gray-900 text-white' : 'bg-gradient-to-br from-gray-50 to-gray-100 text-gray-800'}`}>
      {/* Theme Toggle Button - Fixed Position */}
      <button
        onClick={() => setIsDark(!isDark)}
        className={`fixed top-4 right-4 p-3 rounded-full ${
          isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-white hover:bg-gray-100'
        } shadow-lg transition-all duration-200 z-50`}
        aria-label="Toggle theme"
      >
        {isDark ? <SunIcon size={24} className="text-peach-300" /> : <MoonIcon size={24} className="text-gray-600" />}
      </button>

      {/* Hero Section */}
      <div className={`${isDark ? 'bg-gradient-to-r from-peach-800 to-rose-800' : 'bg-gradient-to-r from-peach-400 to-rose-400'} text-white`}>
        <div className="max-w-6xl mx-auto px-8 py-20">
          <header className="flex flex-col md:flex-row justify-between items-center mb-12">
            <div className="text-center md:text-left mb-8 md:mb-0">
              <h1 className="text-5xl font-bold mb-4 tracking-tight">ANSHU BANU</h1>
              <p className="text-xl text-peach-100">Software Engineer & Web Developer</p>
            </div>
            <div className="flex items-center space-x-6">
              <a href="https://www.linkedin.com/in/anshu-b-243a84264" target="_blank" className="transform hover:scale-110 transition-transform duration-200 hover:text-peach-200">
                <LinkedinIcon size={32} />
              </a>
              <a href="https://github.com/Anshuu03" target="_blank" className="transform hover:scale-110 transition-transform duration-200 hover:text-peach-200">
                <GithubIcon size={32} />
              </a>
              <a href="mailto:anshubanu000@gmail.com" className="transform hover:scale-110 transition-transform duration-200 hover:text-peach-200">
                <MailIcon size={32} />
              </a>
              <a 
                href="https://drive.google.com/file/d/1CIDBp8ycML70R1MshwlBS96SlwBMphK5/view?usp=sharing" 
                target="_blank" 
                className="transform hover:scale-110 transition-transform duration-200 hover:text-peach-200"
                title="View Resume"
              >
                <FileTextIcon size={32} />
              </a>
              <a href="tel:8105452527" className="transform hover:scale-110 transition-transform duration-200 hover:text-peach-200">
                <PhoneIcon size={32} />
              </a>
            </div>
          </header>
        </div>
      </div>

      <main className="max-w-6xl mx-auto px-8 py-16 space-y-20">
        {/* About Section */}
        <section className={`${isDark ? 'bg-gray-800' : 'bg-white'} rounded-2xl p-8 shadow-lg transform hover:shadow-xl transition-shadow duration-300`}>
          <h2 className={`text-3xl font-bold mb-6 flex items-center ${isDark ? 'text-peach-400' : 'text-peach-600'}`}>
            <CodeIcon className="mr-3" /> About Me
          </h2>
          <p className={`text-lg leading-relaxed ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
            Final Year B.E CSE Student passionate about creating innovative solutions through code. 
            Specialized in Web Development (MERN Stack) and Data Science, I combine technical expertise 
            with creative problem-solving to build impactful applications.
          </p>
        </section>

        {/* Skills Section */}
        <section className={`${isDark ? 'bg-gray-800' : 'bg-white'} rounded-2xl p-8 shadow-lg transform hover:shadow-xl transition-shadow duration-300`}>
          <h2 className={`text-3xl font-bold mb-8 flex items-center ${isDark ? 'text-peach-400' : 'text-peach-600'}`}>
            <BookOpenIcon className="mr-3" /> Skills & Expertise
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {Object.entries({
              "Programming Languages": skills.programmingLanguages,
              "Frontend Development": skills.frontend,
              "Backend & Tools": [...skills.backend, ...skills.tools]
            }).map(([category, items]) => (
              <div key={category} className={`${isDark ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-50 hover:bg-gray-100'} rounded-xl p-6 transition-colors duration-200`}>
                <h3 className="font-bold text-xl mb-4">{category}</h3>
                <div className="flex flex-wrap gap-2">
                  {items.map(item => (
                    <span key={item} className={`${isDark ? 'bg-peach-900 text-peach-100' : 'bg-peach-100 text-peach-800'} px-3 py-1 rounded-full text-sm font-medium`}>
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Projects Section */}
        <section className={`${isDark ? 'bg-gray-800' : 'bg-white'} rounded-2xl p-8 shadow-lg transform hover:shadow-xl transition-shadow duration-300`}>
          <h2 className={`text-3xl font-bold mb-8 flex items-center ${isDark ? 'text-peach-400' : 'text-peach-600'}`}>
            <ServerIcon className="mr-3" /> Featured Projects
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <div key={index} className={`${isDark ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-50 hover:bg-gray-100'} rounded-xl p-6 transition-all duration-300 transform hover:-translate-y-1`}>
                <h3 className="font-bold text-xl mb-3">{project.name}</h3>
                <p className={`${isDark ? 'text-gray-300' : 'text-gray-600'} mb-4`}>{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map(tech => (
                    <span key={tech} className={`${isDark ? 'bg-peach-900 text-peach-100' : 'bg-peach-100 text-peach-800'} px-3 py-1 rounded-full text-sm font-medium`}>
                      {tech}
                    </span>
                  ))}
                </div>
                <a 
                  href={project.githubLink} 
                  target="_blank" 
                  className={`inline-flex items-center ${isDark ? 'text-peach-400 hover:text-peach-300' : 'text-peach-600 hover:text-peach-800'} font-medium`}
                >
                  <GithubIcon size={20} className="mr-2" /> 
                  View Project
                  <ExternalLinkIcon size={16} className="ml-1" />
                </a>
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className={`${isDark ? 'bg-gray-950' : 'bg-gray-900'} text-white py-8 mt-20`}>
        <div className="max-w-6xl mx-auto px-8 text-center">
          <p className="text-gray-400">
            © {new Date().getFullYear()} Anshu Banu. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Portfolio;